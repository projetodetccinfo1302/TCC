package com.example.tcc_1302_petmatch.inrerfaces;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.tcc_1302_petmatch.model.Usuario;

import java.util.List;

@Dao
public interface DaoUsuario {
    @Insert
    void Insert(Usuario usuario);

    @Query("SELECT * FROM USUARIO")
    LiveData<List<Usuario>> getAllUsuarios();

}
