package com.example.tcc_1302_petmatch.model;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.tcc_1302_petmatch.MainActivity;
import com.example.tcc_1302_petmatch.R;
import com.example.tcc_1302_petmatch.databinding.ActivityCadastroUsuarioBinding;

import java.util.concurrent.Executors;

public class CadastroUsuario extends AppCompatActivity {
    private ActivityCadastroUsuarioBinding binding;
    private AppDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCadastroUsuarioBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });
        database = AppDatabase.getInstance(this);

        binding.buttonenviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarUsuario();
            }
        });
    }
    String nome; String sobrenome;
    String cpf; String cep;
    String idadeStr;
    String email; String telefone;
    private void salvarUsuario() {
        // Captura os dados digitados na tela
        nome = binding.txtNome.getText().toString().trim();
        sobrenome = binding.txtSNome.getText().toString().trim();
        cpf = binding.txtcpf.getText().toString().trim();
        cep = binding.txtcep.getText().toString().trim();
        idadeStr = binding.txtidade.getText().toString().trim();
        email = binding.txtemail.getText().toString().trim();
        telefone = binding.txtfone.getText().toString().trim();

        // Verifica se algum campo está vazio
        if (nome.isEmpty() || sobrenome.isEmpty() || cpf.isEmpty() || cep.isEmpty() ||
                idadeStr.isEmpty() || email.isEmpty() || telefone.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Converte idade para inteiro
        int idade = Integer.parseInt(idadeStr);

        // Cria um objeto Usuario
        Usuario usuario = new Usuario(nome, sobrenome, cpf, cep, idade, email, telefone);

        // Salva o usuário no banco de dados (em uma thread separada)
        Executors.newSingleThreadExecutor().execute(() -> {
            database.daoUsuario().Insert(usuario);
            runOnUiThread(() -> Toast.makeText(CadastroUsuario.this, "Usuário salvo com sucesso!", Toast.LENGTH_SHORT).show());
        });
    }
}
