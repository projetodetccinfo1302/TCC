package com.example.tcc_1302_petmatch.Model;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import com.example.tcc_1302_petmatch.R;
import com.example.tcc_1302_petmatch.databinding.ActivityCadastroUsuarioBinding;

public class CadastroUsuario extends AppCompatActivity {
private ActivityCadastroUsuarioBinding binding;

    AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCadastroUsuarioBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());

        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "User-database").allowMainThreadQueries().build();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        binding.buttonenviar.setOnClickListener(view -> {
            String nomeusuario = binding.txtNome.getText().toString().trim();
            String sobrenome = binding.txtSNome.getText().toString().trim();
            String email = binding.txtemail.getText().toString().trim();
            String senha = binding.txtsenha.getText().toString().trim();
            String telefone = binding.txtfone.getText().toString().trim();
            String cep = binding.txtcep.getText().toString().trim();
            String cpf = binding.txtcpf.getText().toString().trim();
            String idade = binding.txtidade.getText().toString();
            int idadeuser = Integer.parseInt(idade);
            String tipouser = null;

            if (binding.checkAdotante.isChecked() == true) {tipouser = "Adotante";}
            if (binding.checkAdotante.isChecked() == true) {tipouser = "Doador";}
            if (binding.checkAdotante.isChecked() == true && binding.checkDoador.isChecked() == true) {tipouser = "Adotante e Doador";}

            String finalTipouser = tipouser;


            Usuario user = new Usuario(nomeusuario, sobrenome, email,senha,telefone,cep, cpf, idadeuser, finalTipouser);
            int id = user.codigo;
            if (nomeusuario.isEmpty() || sobrenome.isEmpty() || cpf.isEmpty() || cep.isEmpty() || idadeuser != 0 || email.isEmpty() || telefone.isEmpty() || finalTipouser.isEmpty()){
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (nomeusuario != null && sobrenome != null && email != null && senha != null && telefone  != null
                    && cep != null && cpf != null && idadeuser >= 18 && finalTipouser != null){
                db.daoUsuario().insert(user);
                Toast.makeText(this, "Usuário Cadastrado com Sucesso!", Toast.LENGTH_SHORT).show();
            } else if (nomeusuario != null && sobrenome != null && email != null && senha != null && telefone  != null
                    && cep != null && cpf != null && idadeuser < 18 && finalTipouser != null) {
                Toast.makeText(this, "Você deve ter mais de 18 anos para se cadastrar.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}